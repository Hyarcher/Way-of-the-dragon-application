
package wayofthedragon;

/**
 *
 * @author Up839653
 */
public class WayOfTheDragon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login_Page login = new Login_Page();
        login.setVisible(true);
    }
    
}
